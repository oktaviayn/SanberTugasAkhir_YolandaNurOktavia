// /// <reference types ="cypress"/>

// it('Test Search Google', () => {
//     cy.visit('https://www.google.com/')
//     cy.get('.gLFyf').type('wisnu munawar{enter}')
//     // cy.get('.gLFyf',{timeout: 3000}).type('wisnu munawar{enter}')
//     cy.get('[data-hveid="CAcQAA"] > .jtfYYd > .jGGQ5e > .yuRUbf > a > .TbwUpd > .iUh30').should('be.visible')
//     // cy.contains('Wisnu Munawar - Software Quality Assurance Engineer',{timeout:3000}).click()
// })